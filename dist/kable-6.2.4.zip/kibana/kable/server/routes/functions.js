import _ from 'lodash';

export default function (server) {
  server.route({
    method: 'GET',
    path: '/api/kable/functions',
    handler: function (request, reply) {
      const functionArray = _.map(server.plugins.kable.functions, function (val, key) {
        // TODO: This won't work on frozen objects, it should be removed when everything is converted to datasources and chainables
        return _.extend({}, val, { name: key });
      });
      reply(_.sortBy(functionArray, 'name'));
    }
  });
}
